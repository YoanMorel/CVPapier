$('div.bg-left').css('height', (1123 - $('img.img-fluid').height()) + 'px');
